<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Batch extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'section',
        'date',
    ];
    public function manageEggs() {
        return $this->hasMany(ManageEgg::class);
    }
}
